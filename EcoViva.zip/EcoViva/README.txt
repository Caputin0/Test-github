ECOVIVA - LOJA VIRTUAL SUSTENTAVEL
==================================

ESTADO ATUAL
------------
Esta pasta contém a estrutura inicial do projeto, a conexão PHP com MySQL,
o script de criação do banco e a página inicial com listagem de produtos.

REQUISITOS
----------
- XAMPP com Apache e MySQL
- PHP com extensão PDO MySQL habilitada
- Navegador e editor de código (ex.: VS Code)

INSTALACAO
----------
1. Extraia a pasta EcoViva para:
   C:\xampp\htdocs\

2. Abra o XAMPP e inicie Apache e MySQL.

3. Acesse:
   http://localhost/phpmyadmin

4. Clique na aba SQL e importe/executa o conteúdo de:
   database/ecoviva.sql

5. Confira as credenciais em:
   config/conexao.php
   No XAMPP padrão, o usuário é root e a senha é vazia.

6. Abra:
   http://localhost/EcoViva/

OBSERVACOES
-----------
- Os produtos são cadastrados no banco pelo arquivo SQL.
- Como as imagens dos produtos ainda não foram adicionadas, a página
  mostra um ícone de folha no lugar delas.
- Para exibir o banner, coloque uma imagem chamada banner.jpg em
  assets/img/.
- As páginas de catálogo, login, cadastro, carrinho, pedidos e painel
  administrativo serão implementadas nas próximas etapas.
- Não existe ainda um fluxo real de compra ou pagamento.
- Não publique o projeto com credenciais padrão ou sem configurar
  autenticação e permissões adequadas.

ESTRUTURA
---------
EcoViva/
  index.php
  config/conexao.php
  assets/css/style.css
  assets/js/
  assets/img/
  database/ecoviva.sql
