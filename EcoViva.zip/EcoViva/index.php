<?php
require_once "config/conexao.php";

$sql = "SELECT produtos.*, categorias.nome AS categoria
        FROM produtos
        LEFT JOIN categorias ON produtos.categoria_id = categorias.id
        WHERE produtos.ativo = 1
        ORDER BY produtos.id DESC
        LIMIT 6";

$produtos = $pdo->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoViva | Consumo consciente</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="cabecalho">
    <a href="index.php" class="logo">Eco<span>Viva</span></a>
    <nav>
        <a href="index.php">Início</a>
        <a href="produtos.php">Produtos</a>
        <a href="ods.php">ODS</a>
        <a href="sobre.php">Sobre nós</a>
        <a href="contato.php">Contato</a>
    </nav>
    <div class="acoes">
        <a href="cliente/login.php">Entrar</a>
        <a href="carrinho/index.php" class="botao-carrinho">Carrinho</a>
    </div>
</header>

<main>
    <section class="banner">
        <div class="banner-conteudo">
            <span class="etiqueta">CONSUMO CONSCIENTE</span>
            <h1>Pequenas escolhas,<br><span>grandes mudanças.</span></h1>
            <p>Descubra produtos sustentáveis e faça parte de um movimento por um planeta melhor.</p>
            <a href="produtos.php" class="botao-principal">Explorar produtos</a>
        </div>
    </section>

    <section class="apresentacao">
        <h2>Um futuro mais sustentável começa aqui.</h2>
        <p>A EcoViva nasceu com o propósito de incentivar o consumo responsável, oferecendo alternativas que ajudam a reduzir os impactos ambientais.</p>
    </section>

    <section class="secao-produtos">
        <div class="titulo-secao">
            <div>
                <span class="subtitulo">NOSSA SELEÇÃO</span>
                <h2>Produtos em destaque</h2>
            </div>
            <a href="produtos.php">Ver todos →</a>
        </div>

        <div class="grade-produtos">
            <?php foreach ($produtos as $produto): ?>
                <article class="card-produto">
                    <div class="imagem-produto">
                        <?php
                        $arquivo = "assets/img/" . ($produto["imagem"] ?? "");
                        if (!empty($produto["imagem"]) && is_file($arquivo)):
                        ?>
                            <img src="<?= htmlspecialchars($arquivo, ENT_QUOTES, "UTF-8") ?>"
                                 alt="<?= htmlspecialchars($produto["nome"], ENT_QUOTES, "UTF-8") ?>">
                        <?php else: ?>
                            <span aria-hidden="true">🌱</span>
                        <?php endif; ?>
                    </div>
                    <div class="informacoes-produto">
                        <span class="categoria"><?= htmlspecialchars($produto["categoria"] ?? "Sustentável", ENT_QUOTES, "UTF-8") ?></span>
                        <h3><?= htmlspecialchars($produto["nome"], ENT_QUOTES, "UTF-8") ?></h3>
                        <p><?= htmlspecialchars($produto["descricao"] ?? "", ENT_QUOTES, "UTF-8") ?></p>
                        <div class="preco">R$ <?= number_format((float)$produto["preco"], 2, ",", ".") ?></div>
                        <a href="produto.php?id=<?= (int)$produto["id"] ?>" class="botao-produto">Ver produto</a>
                    </div>
                </article>
            <?php endforeach; ?>

            <?php if (!$produtos): ?>
                <p>Nenhum produto disponível no momento.</p>
            <?php endif; ?>
        </div>
    </section>

    <section class="secao-ods">
        <span class="subtitulo">NOSSO COMPROMISSO</span>
        <h2>Conectados aos Objetivos de Desenvolvimento Sustentável</h2>
        <p>A EcoViva busca contribuir para um mundo melhor por meio do consumo responsável e da preservação dos recursos naturais.</p>
        <div class="ods-lista">
            <div class="ods-item"><strong>ODS 12</strong><span>Consumo e produção responsáveis</span></div>
            <div class="ods-item"><strong>ODS 13</strong><span>Ação contra a mudança do clima</span></div>
            <div class="ods-item"><strong>ODS 14</strong><span>Vida na água</span></div>
            <div class="ods-item"><strong>ODS 15</strong><span>Vida terrestre</span></div>
        </div>
        <a href="ods.php" class="botao-principal">Conheça os ODS</a>
    </section>
</main>

<footer class="rodape">
    <h2>EcoViva</h2>
    <p>Consumo consciente para um futuro melhor.</p>
    <p>© <?= date("Y") ?> EcoViva. Todos os direitos reservados.</p>
</footer>
</body>
</html>
