CREATE DATABASE IF NOT EXISTS ecoviva
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE ecoviva;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('cliente', 'admin') NOT NULL DEFAULT 'cliente',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT
) ENGINE=InnoDB;

CREATE TABLE ods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero INT NOT NULL UNIQUE,
    titulo VARCHAR(150) NOT NULL,
    descricao TEXT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT NULL,
    ods_id INT NULL,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0,
    imagem VARCHAR(255),
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_produto_categoria FOREIGN KEY (categoria_id)
        REFERENCES categorias(id) ON DELETE SET NULL,
    CONSTRAINT fk_produto_ods FOREIGN KEY (ods_id)
        REFERENCES ods(id) ON DELETE SET NULL,
    CONSTRAINT chk_produto_preco CHECK (preco >= 0),
    CONSTRAINT chk_produto_estoque CHECK (estoque >= 0)
) ENGINE=InnoDB;

CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valor_total DECIMAL(10,2) NOT NULL,
    status ENUM('pendente', 'pago', 'enviado', 'entregue', 'cancelado')
        NOT NULL DEFAULT 'pendente',
    CONSTRAINT fk_pedido_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id)
) ENGINE=InnoDB;

CREATE TABLE itens_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_pedido FOREIGN KEY (pedido_id)
        REFERENCES pedidos(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_produto FOREIGN KEY (produto_id)
        REFERENCES produtos(id),
    CONSTRAINT chk_item_quantidade CHECK (quantidade > 0),
    CONSTRAINT chk_item_preco CHECK (preco_unitario >= 0)
) ENGINE=InnoDB;

INSERT INTO categorias (nome, descricao) VALUES
('Casa sustentável', 'Produtos ecológicos para o lar'),
('Cuidados pessoais', 'Produtos de higiene e autocuidado'),
('Acessórios', 'Acessórios reutilizáveis e ecológicos'),
('Natureza', 'Produtos que incentivam a preservação ambiental');

INSERT INTO ods (numero, titulo, descricao) VALUES
(12, 'Consumo e produção responsáveis',
 'Incentivar padrões sustentáveis de consumo e produção.'),
(13, 'Ação contra a mudança global do clima',
 'Adotar medidas urgentes para combater as mudanças climáticas.'),
(14, 'Vida na água',
 'Conservar e utilizar sustentavelmente os oceanos e recursos marinhos.'),
(15, 'Vida terrestre',
 'Proteger ecossistemas terrestres e combater a perda da biodiversidade.');

INSERT INTO produtos
(categoria_id, ods_id, nome, descricao, preco, estoque, imagem)
VALUES
(3, 12, 'Garrafa reutilizável',
 'Garrafa para reduzir o consumo de plástico descartável.',
 39.90, 20, 'garrafa.jpg'),
(1, 12, 'Kit de utensílios de bambu',
 'Utensílios reutilizáveis produzidos com bambu.',
 29.90, 15, 'bambu.jpg'),
(2, 12, 'Sabonete natural',
 'Sabonete artesanal com ingredientes de origem vegetal.',
 14.90, 30, 'sabonete.jpg'),
(3, 14, 'Ecobag reutilizável',
 'Sacola reutilizável para substituir sacolas descartáveis.',
 24.90, 25, 'ecobag.jpg'),
(4, 15, 'Kit de plantio',
 'Kit para incentivar o cultivo de plantas em casa.',
 34.90, 12, 'plantio.jpg'),
(1, 13, 'Luminária solar',
 'Iluminação que utiliza energia solar.',
 69.90, 10, 'luminaria.jpg');
